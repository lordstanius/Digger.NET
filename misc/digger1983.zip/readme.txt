The original 1983 DIGGER.COM executable.
Game can be run via DOSBox x86 emulator ( http://www.dosbox.com/ ), with setting "machine=cga" in dosbox.conf file.
