/* Digger Remastered
   Copyright (c) Andrew Jenner 1998-2004 */

extern HWND g_hDlg;
extern HWND hInputConfigWnd;
bool create_config_window();
